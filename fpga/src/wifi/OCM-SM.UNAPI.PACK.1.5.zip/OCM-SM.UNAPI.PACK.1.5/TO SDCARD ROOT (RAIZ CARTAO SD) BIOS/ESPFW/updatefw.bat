cfg8266 fw.bin
waitwifi
cfg8266 certs.bin /c