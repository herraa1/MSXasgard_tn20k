This pack contains the UNAPI Memory Mapper/RAM Driver that allow MSX 
UNAPI applications to use the WiFi capabilities of your SM-X. The ESP8266 UNAPI
firmware, the ESP8266 RAM UNAPI driver as well as some of the UNAPI
applications updates were made by me ( Oduvaldo Pavan Junior - ducasp@gmail.com
). It also contains a SD-BIOS with Nextor and that has an UNAPI compatible BIOS,
if you choose that version, you won't need to use the driver and the clock can
be updated automatically during the boot, faster than than using SNTP and
WAITWIFI.

With this package you will have your SM-X fully UNAPI TCP-IP v1.1 compliant.
Those are the features supported by this implementation using ESP8226.COM v1.1
and firmware version 1.4:

- It fully implements UDP connections.

- It fully implements TCP active connections. TLS (encrypted) connections are 
supported, including validating server certificate and hostname. There is one
shortcoming that it is not possible at this moment to choose the local port
used for a TLS connection, it will be random even if a specific port is 
requested. This poses no issue to actual applications.

- It fully implements TCP passive connections.

- It supports up to 4 different connections, using a shared pool. That means 4
connections total, not 4 TCP and 4 UDP.

- Only one TLS connection is allowed, no matter how many free connections exist
This is due to the fact that TLS requires a huge receiving buffer of 16KB and 
encryption and decryption also requires big RAM buffers and ESP8266 has limited
RAM available.

- RAW TCP connections and ECHO are not supported.

IMPORTANT: to use a SD-BIOS in OCM up to version 3.9, OCM-BIOS.DAT file has to
be the first file being created in the file system. Using 3.9.1 or newer, you
just have a restriction that the file has to be placed in the root folder, its
name should be OCM-BIOS.DAT and it can't be fragmented. The best way to avoid
issues with file order or fragmentation still is to use OCM-BIOS.DAT as the
first file, and then when you want to move to a different SD-BIOS, copy the new
one over it, so it is overwritten. So, if you already have a card with an
SD-BIOS, just overwrite it to update, file order is kept and file won't be
fragmented. If you opt to no longer use OCM-BIOS.DAT w/ UNAPI BIOS, you can
just copy an OCM-BIOS.DAT that doesn't have UNAPI BIOS, or, simply delete the
file so your device will use the standard BIOS in the FLASH memory that loads
the FPGA. If you are using version 3.9.1 or newer, you can just rename the file
extension from .DAT to .OLD.

IMPORTANT: before moving to WiFi SD-BIOS, UPDATE ESP8266 firmware using the
files CFG8266.COM, FW.BIN and CERTS.BIN on ESPFW folder (you have updatefw.bat
in there that automates the firmware update)! If you fail to do it, WiFi 
configurator won't work properly!

IMPORTANT: THERE IS A CHANGE IN THE DEFAULT BEHAVIOR OF WIFI

The version shipped with all SM-X up to June 2020 will leave the WiFi radio of
ESP8266 on all the times. Once you set-up a network to connect to, it will
either connect and stay connected or keep trying to connect to that network. It
has come to my attention that there are SM-X devices that the WiFi radio is
interfering with the audio output, generating noises. Mine doesn't do that, so
I've never thought about needing to turn WiFi off. So, the new firmware in this
package (ESP firmware version 1.2) has a different approach:

1 - Once powered-on it won't turn WiFi radio on
2 - WiFi radio will be turned on once the ESP receives any command that is not
    a RESET command
3 - Once the device is idle (not receiving any command), it will wait a timeout
    (default is 120 seconds / 2 minutes), if no commands are received within 
    this period, device will check if there are any open connections, and if
    not, turn the WiFi radio off
4 - If WiFi radio is off and any command received, we are back to step 2

If using the SD-BIOS option, that behavior can be changed by accessing the WiFi
configurator. To access it, keep F1 pressed during boot. When the configurator
appears, choose option 2 to configure when WiFi is on. There are two options:

ALWAYS ON: choosing 0 as period, WiFi will be always on

TURN OFF WHEN IDLE: choosing from 1 to 999 as period, WiFi will be on when
starting up, and when the period choosen elapses since the last command
received by the WiFi interface, it will be checked if there are any open 
connections (i.e.: an application using a conexion), if there is, time-out will
be re-scheduled for the same period to be checked again. If no connections are
open, WiFi will be turned off. Minimum period is 30, if you choose from 1 to 29
, 30s will be the effective period. Maximum period is 600s, if you choose from
601 to 999, 600s will be the effective period.

Configurator option 4 allows you to fully disable UNAPI and WiFi by choosing
item 3. It is possible to choose option 0 for a faster boot having UNAPI
enabled, however SM-X clock won't be updated automatically. Finally, options
1 and 2 will configure SM-X clock during boot, using SNTP, not needing DOS.
That is a faster option than using WAITWIFI and SNTP in your autoexec.bat. The
difference between options 1 and 2 is that option 1 will respect the WiFi
time-out configurations to determine when/if WiFi is turned off, while option
2 will turn off WiFi immediatelly after configuring SM-X clock.

If you opt to use the RAM driver, CFG8266.COM also supports turning radio off
immediately, so those that normally use WiFi to set SM-X clock with SNTP.COM,
can add CFG8266.COM /O as the last command of their AUTOEXEC chain routine 
(usually it ends in AUTOEXE2.BAT) if your SM-X audio is affected by WiFi radio.
If you do not have this issue and just want to have the network always on, like
before, simply execute:
    CFG8266 /T 0
And it will work like before, always on since power up, never turning off the
WiFi radio. (NOTE: do not include CFG8266 /T 0 in your AUTOEXEC chain routine,
this is saved to flash memory and restored on power up, no need to do it)

Basic instructions:

TO SDCARD ROOT (RAIZ CARTAO SD) : move those files to your MSX-SM SDCARD. 

NOTE: There are two folders, one ends with RAM, if you wanna use UNAPI driver,
other ends with BIOS, if you wanna use UNAPI BIOS.

    UNAPI BIOS / SD-BIOS: package is supplied with five files, OCM-BIOS.DAT is
    a copy of NEXWIFI.DAT and has Nextor Kernel and Wi-Fi BIOS. If you prefer
    to use DOS2 Kernel, you can copy DOSWIFI.DAT over OCM-BIOS.DAT with COPY
    DOSWIFI.DAT OCM-BIOS.DAT in MSX-DOS prompt. Also you will find DOS.DAT and
    NEX.DAT, which are versions without built-in UNAPI BIOS. You can copy them
    over OCM-BIOS.DAT as mentioned above as needed.

    BE CAREFUL! AUTOEXEC.BAT is included. Edit it first with the options of 
    your own SDCARD. YOU HAVE BEEN WARNED!

    Notes about AUTOEXEC.BAT and AUTOEXE2.BAT if you choose the RAM driver:
    UNAPI driver is loaded on memory mapper, and per UNAPI specifications
    RAMHELPR is needed. RAMHELPR go to MSX BASIC briefly to load some data and
    then returns to MSX-DOS / NEXTOR. So, once it returns MSX-DOS / NEXTOR is
    reloaded and this kills anything set before (i.e.: path). But, RAMHELPR
    allows calling another executable or bat file, and then AUTOEXE2.BAT is
    called in this case, where you should have all your regular AUTOEXEC.BAT
    stuff. If you choose the SD-BIOS version, RAMHELPR is not used and we have
    only AUTOEXEC.BAT.

    Notes about SNTP if you choose the RAM driver: change the second line on
    AUTOEXE2.BAT to your own time zone, by default it is GMT -03:00 that covers
    most of Brazil. When using SD-BIOS, instead of having SNTP.COM and WAITWIFI
    on your AUTOEXEC.BAT, I recommend using the BIOS capability to
    automatically adjust time and date of your SM-X at boot, it is way faster.
    To configure it, access the WiFi configurator (during boot keep F1 pressed
    until configurator pops-up), choose option 4, and there choose option 2. It
    will ask your GMT offset, only full hour GMT offsets are accepted, you can
    use - as the first digit to set it up to -3 as an example.

Now telling about how to configure WiFi and some parameters:

    Using SD-BIOS and the WiFi configurator:

    Access configurator keeping F1 pressed during boot. On some devices you may
    need to press and keep F1 pressed, reset, and only release F1 after
    entering the BIOS menu.

    To connect to your router/access point:
    Use option 3, it will scan available networks so you can choose which one
    to connect.

    To change Nagle Algorithm and turn it on (default is off once powered up):
    Use option 1, you can toggle it On or Off. For an explanation about Nagle
    algorithm, check the section about configuring it using CFG8266.COM

    To control how long WiFi is on when idle:
    Use option 2. Type a number ranging from 0 and 999

    If 0, it will keep WiFi always on

    If it is a value ranging from 1 to 30, it will keep WiFi on up to 30s when
    idle

    If it is a value ranging from 31 to 600, it will keep WiFi on up to xs when
    idle

    If a value higher than 600, it will act the same as if 600 was choosen

    Using RAM driver (also works if you use SD-BIOS):
    Use CFG8266.COM (it is in WIFI folder, that should be on your PATH as well)

    To connect to your router/access point:
        CFG8266.COM /S 
    It will scan available networks, list up to 10, and you can choose it. If
    a password is required, it will be requested (password is SHOWN on screen).

    To turn off the WiFi radio immediatelly:
        CFG8266.COM /O
    As long as there is no connection (TCP/UDP) open, WiFi radio will be turned
    off. To turn it back on you can just call WAITWIFI.COM or just execute the
    internet/network program you want to use. Most programs will work (except
    it will take a little longer to connect as first WiFi need to be turned on
    and then connect to the router, this takes a few seconds), if the program
    doesn't work the first time, wait a few seconds and try again. (by calling
    WAITWIFI.COM, it should always work after WAITWIFI returns)

    IMPORTANT: The options described below are saved on flash memory and are
    automatically restored upon SM-X being powered on. DO NOT include those
    options in AUTOEXEC.BAT / AUTOEXE2.BAT, this will wear out ESP's flash
    memory, it has a limited lifespan of up to 10000 writes. It is more than
    enough to use those options whenever you feel you need to change them (if
    changing it once a day, that means more than 25 years are needed to wear
    out the EEPROM). So, whenever you need to change those behaviors, execute
    CFG8266 ony once with the new values.

    To change Nagle Algorithm and turn it on (default is off once powered up):
        CFG8266.COM /M
    To turn Nagle Algorithm off:
        CFG8266.COM /N
    About Nagle Algorithm: basically it will hold sending data over network
    until the previous data has been ACKed or a certain treshold of data size
    waiting to be sent is reached. As an example, FTP will send data, and even
    though it has already requested a second packet to be sent, that packet 
    won't be sent until the ACK from the server telling it has received the 1st
    packet is received. This might hurt performance on connections with high
    latency as well on connections with computers/servers that use delayed ACK
    (i.e.: Windows uses 250ms delayed ACK, so it won't send back the ACK until
    a second package is received or 250ms have passed. In this case, our side
    with Nagle On is waiting ACK before sending the second package... End result
    is that you end-up transferring only 4 packets per second no matter how
    fast your MSX and Internet Connection are.
    On the other hand Nagle might be handy for certain applications that send
    several small packets (i.e.: telnet). So, you have the option to turn Nagle
    On to try to improove performance on some applications.

    To control how long WiFi is on when idle:
        CFG8266.COM /T x
            x -> a number ranging from 0 to 600

    If x is 0, it will keep WiFi always on

    If x is a value ranging from 1 to 30, it will keep WiFi on up to 30s when
    idle

    If x is a value ranging from 31 to 600, it will keep WiFi on up to xs when
    idle

Files and versions (when applicable) contained in this package:

OCM-BIOS.DAT - This SD-BIOS and all variants were built in December 2023 and
have the Nextor Kernel of the same date, version 2.1.2

FW.BIN - v1.4 / March 2025: this is a customized firmware for ESP8266
implementing UNAPI TCP-IP specification 1.1.

CERTS.BIN - this is a list of trusted CA and their certificates. The list is
the same used by Firefox and has been generated January/2025

AUTOEXEC.BAT and AUTOEXE2.BAT (if you choose RAM driver) - those are files that
start the ESP8266 ESP driver automatically, wait it to connect to your router
/ AP and then update MSX-SM clock with time from a SNTP server, and also will
have the UNAPI and WiFi applications on the DOS path

AUTOEXEC.BAT (if you choose SD-BIOS) - file that will have the UNAPI and WiFi
applications on the DOS path

ESP8266.COM - v1.1 / June 2020: UNAPI driver that tunnels UNAPI requests to the
ESP8266 and that pack the responses from ESP properly so UNAPI applications can
access it.

CFG8266.COM - v1.3 / August 2020: Helper tool that allows you to:
    - List available Access Points / Routers (up to 10) and connect to it.
    - Turn Nagle Algorithm On/Off (default is OFF after power up)
    - Change the behavior of WiFi when idle (time out)
    - Update firmware or certificates from your MSX using .BIN files
    - Update firmware or certificates from a HTTP server
    * When you update firmware, you need to reload certificates.

TERM8266.COM - v1.0 / June 2019: simple TTY terminal to send keyboard keys to
ESP8266 and read what ESP8266 sends back. Can be requested to be used to help
understand/debug an issue.

WAITWIFI.COM - v0.14 / August 2020: Helper tool that will wait until the first
TCP IP UNAPI reports connection is OPEN or 10 seconds have elapsed. It helps if
you want to call UNAPI applications (i.e.: SNTP) in your AUTOEXEC.BAT, to give
time to the UNAPI device to connect after loading its driver (ESP8266 driver
won't lock waiting for network connection at start-up). A big thank you to KDL
that has provided the code for the /T option, that minimizes text output.

FTP.COM - v1.0 / April 2010: FTP Client made by Konamiman. Remember to set type
to BINARY before getting or sending files.

GETURL.COM - v1.0 / January 2011: Helper tool made by Konamiman that will read
a list of URLs in a file. Can be used with HGET to get a list of files.

HGET.COM - v1.3 / July 2019: Update made by me based on Konamiman HGET v1.0. It
allows also HTTPS URLs as long as the adapter supports ACTIVE TLS Connections,
like your MSX-SM ESP8266 UNAPI does. :) It also improove performance compared
to the original version due to changing a behavior in the receiving file routine
as well as the behavior to indicate progress of file download on screen.

OBSOFTP.COM - v1.0 / April 2011: FTP Server made by Konamiman. Allow you to have
any folder and its subfolders (even root folder) shared in a FTP server. Please
notice it DOES NOT HAVE ANY AUTHENTICATION, so be careful if you use it to allow
file writes from clients.

OBSOSMB.COM - v1.0 / April 2011: SMB Server made by Konamiman. Notice that it is
not fully SMB compliant and Konamiman says it works only with Windows Clients, 
I've seen it freezing when trying to push files from an Android device. Also 
notice that SMB is heavywheight for an 8 bits processor so its performance is
not really fast.

RAMHELPR.COM - v1.2 / June 2019: Helper utility made by Konamiman that allow
applications to easily access routines / drivers that run on a Memory Mapper
segment, like ESP8266.COM driver does. :)

SNTP.COM - v1.1 / July 2019: SNTP Client based on the original SNTP.COM made by
Konamiman that will set your MSX clock with the time received from a SNTP
server like your PC does. This version has a minor fix, his original SNTP.COM
would set MSX clock to HH:MM-1:60 instead of HH:MM:00 if seconds received from
SNTP server were multiple of 60. 

TCPCON.COM - v1.1 / February 2014: Made by Konamiman, it is not really a telnet
client as it doesn't implement telnet specifics like the handshake to exchange
what server offer and what terminal can do, but it works to connect to telnet 
servers in general. :)

TCPIP.COM - v1.1 / June 2019: Helper utility made by Konamiman that allow you 
to check what your device UNAPI implements and can do, as well to configure IP
and other network parameters manually if you want to do so.

TFTP.COM - v1.1 / July 2019: TFTP client updated by me based on TFTP v1.0 made
by Konamiman. This version improves performance compared to the original 
version due to changing a behavior in the receiving file routine as well as the
behavior to indicate progress of file download on screen.

SFTP.COM - v1.3 / May 2019: It is a really fast FTP tool that can be used to
sync your MSX files with files stored in a FTP server and vice versa. Please 
notice it doesn't work with any FTP server as it requires that the server 
supports STAT command and return file list in UNIX mode, and at this moment it
only connects to servers using PORT 21 as well. ( Windows built-in FTP server 
in IIS services supports this, Filezilla doesn't) I've included a few batch 
files that are examples to get, update or send files.

HUB.COM - v1.0.6 / April 2023: MSX HUB is a nice repository of homebrew and
free games and applications. It allows you to install, remove, update, etc. It
is the oficial version, that now incorporates all my improvments as well all
new improvments done by the original author

HUBG.COM - v0.90 / April 2023: Menu Driven and Color version of HUB, with a
(hopefully) friendly user interface, that has been created by me

TELNET.COM - v1.34/ November 2020: It is a fully featured TELNET terminal, and 
it ill allow you to see ANSI animations and colored menus as well as use IBM-PC
character set. It is way faster than TCPCON and also supports transferring 
files using X/Y MODEM (G). Always prefer YMODEM-G, other options are really, 
really, really slow (and it is not possible to be faster receiving 128 bytes 
blocks every 1/4s as those protocols wait a response from the receiving end 
before sending the next packet... so if you have 125ms ping to the server, 
every 128byte it will take 125ms from the time the last byte was sent until you
receive and more 125ms until the server receive your confirmation and more 
125ms to receive the first byte of the next block, you can see how this is 
going to be DEAD SLOW)